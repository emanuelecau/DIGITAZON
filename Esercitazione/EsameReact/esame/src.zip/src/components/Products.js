// import React from 'react'
// import '../App.css'
// import { useState, useEffect } from 'react'




// export default function Products() {
//     const [products, setProducts] = useState([])

//     useEffect(() => {
//         async function getProducts() {
//             const prod = await fetch('https://dummyjson.com/products')
//             const prodlist = await prod.json()
//             setProducts(prodlist.slice(0, 10))
//         }
//         getProducts()

//     }, [])

//     return (
//         <div className='container'>
//             <div>Products</div>
//             <ul>
//                 {products.map(product => (
//                     <li key={product.id}>{product.title}</li>
//                 ))}
//             </ul>

//         </div>

//     )
// }
