import { useState } from 'react'

import '../App.css'
export default function HomePage() {



    return (
        <div className='container'>
            <h1>HomePage</h1>
            <nav>
                <ul>

                </ul>
            </nav>

        </div>
    );
}