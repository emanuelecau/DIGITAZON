import React, { useState, useEffect } from 'react';
import './App.css';

function Cart({ cartItems, removeFromCart }) {
  return (
    <div className="cart">
      <h2>Cart</h2>
      <ul>
        {cartItems.map((item) => (
          <li key={item.id}>
            {item.title} - Quantity: {item.quantity}
            <button onClick={() => removeFromCart(item.id)}>Remove</button>
          </li>
        ))}
      </ul>
    </div>
  );
};

function SearchBar({ products, onSearch }) {
  const [searchTerm, setSearchTerm] = useState('');

  const handleSearch = () => {
    const filteredProducts = products.filter((product) =>
      product.title.toLowerCase().includes(searchTerm.toLowerCase())
    );
    onSearch(filteredProducts);
  };

  return (
    <div className="search-bar">
      <input
        type="text"
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />
      <button onClick={handleSearch}>Search</button>
    </div>
  );
};

function App() {
  const [products, setProducts] = useState([]);
  const [filteredProducts, setFilteredProducts] = useState([]);
  const [cartItems, setCartItems] = useState([]);

  useEffect(() => {
    async function fetchProducts() {

      const response = await fetch('https://dummyjson.com/products');
      const productData = await response.json();
      const productList = Object.values(productData); // Converti l'oggetto in un array di prodotti
      setProducts(productList);
      setFilteredProducts(productList);

    };

    fetchProducts();
  }, []);

  function handleSearch(filteredProducts) {
    setFilteredProducts(filteredProducts);
  };

  function addToCart(product) {
    const existingItem = cartItems.find((item) => item.id === product.id);

    if (existingItem) {
      const updatedCart = cartItems.map((item) =>
        item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
      );
      setCartItems(updatedCart);
    } else {
      const newItem = { ...product, quantity: 1 };
      setCartItems([...cartItems, newItem]);
    }

  };
  function removeFromCart(itemId) {
    const updatedCart = cartItems.filter((item) => item.id !== itemId);
    setCartItems(updatedCart);
  };

  return (
    <div className="container">
      <h1>My Store</h1>
      <SearchBar products={products} onSearch={handleSearch} />
      <ul>
        <div className='products'>
          {filteredProducts.map((product) => (
            <li key={product.id}>
              <h2>Product: {product.title}</h2>
              <span>{product.image}</span>
              <p>Description: {product.description}</p>
              <p>Price: {product.price}</p>

              <button onClick={() => addToCart(product)}>Add to Cart</button>
            </li>
          ))}
        </div>
      </ul>
      <Cart cartItems={cartItems} removeFromCart={removeFromCart} />
    </div>
  );
};

export default App;